

  (c) Iqbal Shah, Thomas Sourmail, Prof. H. K. D. H. Bhadeshia,
      University of Cambridge, September 2002


This file contains the steps to run the Model.
This model predicts the ultimate tensile strength of austenitic stainless steels at certain temperatures as a function of chemical composition and heat treatment.

1) Copy the files onto your hard disk without disturbing the structure and then remove the "READ-ONLY" status for files 'test.dat'.

2) Edit the test.dat file to set input variables.
 
 The input variables are in row;

Column Variable		
1 Chromium (wt%)
2 Nickel (wt%)
3 Molybdenum (wt%)
4 Manganese (wt%)
5 Silicon (wt%)
6 Niobium (wt%)
7 Titanium (wt%)
8 Vanadium (wt%)
9 Copper (wt%)
10 Nitrogen (wt%)
11 Carbon (wt%)
12 Boron (wt%)
13 Phosphorus (wt%)
14 Sulphur (wt%)
15 Cobalt (wt%)
16 Aluminium (wt%)
17 Ratio
18 Solid solution temperature (K)
19 Test temperature (K)

	
3) Double click on "MODEL.exe'' icon , to run program.

4) Results (Ultimate tensile strength in MPa) are stored in a file called 'result.dat'. The format of this file is;


UTS			 Error bar		UTS - error bar		UTS + error bar	
394.067596 		24.871452 		369.196167 		418.939056
396.148041 		20.314295		375.833740 		416.462341
397.592438 		16.408314 		381.184143		414.000763
398.338440 		13.777855 		384.560608 		412.116302
398.343658 		13.010531 		385.333099 		411.354187
397.587799 		13.986557 		383.601257		411.574371
396.071045 		15.881680 		380.189362		411.952728
393.808868		17.922106 		375.886780 		411.730988
390.825867 		19.686657 		371.139191		410.512512
387.146637 		21.046757 		366.099854 		408.193390

End of task.

